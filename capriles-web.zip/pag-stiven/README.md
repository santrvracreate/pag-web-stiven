# Unidad Educativa José Leoncio Capriles

Sitio institucional estático con cuatro páginas independientes. HTML5, CSS y JavaScript, sin frameworks ni instalación de dependencias.

## Abrir

Abrir **index.html** con doble clic. Los enlaces, el buscador y las galerías funcionan también sin servidor y sin conexión a Internet.

Para una vista previa HTTP, si Node.js está instalado:

    node tools/serve.cjs

Abrir http://127.0.0.1:4173. Detener el servidor con Ctrl+C.

## Contenido

- index.html: inicio y reseña histórica con fuentes enlazadas.
- profesores.html: director y 30 docentes únicos en 14 áreas.
- banda.html: carrusel y galería de las cinco fotografías disponibles.
- escoltas.html: las tres fotografías disponibles.
- styles.css: estilos comunes y diseño adaptable.
- script.js: menú, filtros, carrusel y visor accesible.
- docentes.js: estructura JavaScript del plantel, con rutas y reseñas revisadas.
- assets/fonts/: fuentes locales Inter y Merriweather.

Las carpetas originales y sus archivos permanecen con sus nombres exactos. Los textos fuente están en profesores/.

Mariela Orellana Jaldín tiene una sola ficha con Física y Química. María Rossmery Rocabado se presenta con iniciales, ya que no hay una fotografía individual. Las presentaciones de Limbert Cesar Orellana y Jhenny Morales Espinoza describen su pertenencia al plantel y su asignatura: no hay una trayectoria individual documentada en los recursos proporcionados. Las demás reseñas se ampliaron a partir de sus textos originales.

## Mantenimiento

El sitio entregado no necesita generación. Para regenerar las páginas después de editar docentes.js:

    python tools/build-pages.py

Las reseñas revisadas y el inventario de archivos también se conservan en tools/prepare-content.py. Las ampliaciones están en tools/expanded-reviews.py; sus fuentes y el criterio editorial se documentan en tools/content-sources.md. Si se modifica este archivo, ejecutar primero:

    python tools/prepare-content.py
    python tools/build-pages.py

El primer comando regenera docentes.js; sobrescribe cualquier edición manual de ese archivo. El segundo regenera los cuatro HTML. Ambos usan únicamente la biblioteca estándar de Python.

El año del pie de página se actualiza mediante JavaScript. El carrusel no avanza automáticamente. El visor admite Escape, flechas de teclado y gestos táctiles.
